﻿namespace WF_Lab
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ключToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зашифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.расшифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ключЗашифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ключРасшифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всёToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКлючToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьВсёToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(12, 85);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(374, 94);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(497, 85);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(374, 94);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(335, 249);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(216, 47);
            this.textBox3.TabIndex = 2;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(404, 215);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ключ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(519, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(333, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "Зашифрованное сообщение";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(346, 31);
            this.label3.TabIndex = 5;
            this.label3.Text = "Расшифрованное сообщение";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(70, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 47);
            this.button1.TabIndex = 6;
            this.button1.Text = "Зашифровать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(617, 249);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(196, 47);
            this.button2.TabIndex = 7;
            this.button2.Text = "Расшифровать";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(644, 185);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Очистить поле";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(400, 302);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Очистить поле";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(139, 185);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(102, 23);
            this.button5.TabIndex = 10;
            this.button5.Text = "Очистить поле";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(3, 302);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(117, 23);
            this.button6.TabIndex = 11;
            this.button6.Text = "Очистить все поля";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(897, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ключToolStripMenuItem,
            this.зашифрованноеСообщениеToolStripMenuItem,
            this.расшифрованноеСообщениеToolStripMenuItem,
            this.ключЗашифрованноеСообщениеToolStripMenuItem,
            this.ключРасшифрованноеСообщениеToolStripMenuItem,
            this.всёToolStripMenuItem});
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            // 
            // ключToolStripMenuItem
            // 
            this.ключToolStripMenuItem.Name = "ключToolStripMenuItem";
            this.ключToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.ключToolStripMenuItem.Text = "Ключ";
            this.ключToolStripMenuItem.Click += new System.EventHandler(this.ключToolStripMenuItem_Click);
            // 
            // зашифрованноеСообщениеToolStripMenuItem
            // 
            this.зашифрованноеСообщениеToolStripMenuItem.Name = "зашифрованноеСообщениеToolStripMenuItem";
            this.зашифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.зашифрованноеСообщениеToolStripMenuItem.Text = "Зашифрованное сообщение";
            this.зашифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.зашифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // расшифрованноеСообщениеToolStripMenuItem
            // 
            this.расшифрованноеСообщениеToolStripMenuItem.Name = "расшифрованноеСообщениеToolStripMenuItem";
            this.расшифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.расшифрованноеСообщениеToolStripMenuItem.Text = "Расшифрованное сообщение";
            this.расшифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.расшифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // ключЗашифрованноеСообщениеToolStripMenuItem
            // 
            this.ключЗашифрованноеСообщениеToolStripMenuItem.Name = "ключЗашифрованноеСообщениеToolStripMenuItem";
            this.ключЗашифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.ключЗашифрованноеСообщениеToolStripMenuItem.Text = "Ключ + зашифрованное сообщение";
            this.ключЗашифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.ключЗашифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // ключРасшифрованноеСообщениеToolStripMenuItem
            // 
            this.ключРасшифрованноеСообщениеToolStripMenuItem.Name = "ключРасшифрованноеСообщениеToolStripMenuItem";
            this.ключРасшифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.ключРасшифрованноеСообщениеToolStripMenuItem.Text = "Ключ + расшифрованное сообщение";
            this.ключРасшифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.ключРасшифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // всёToolStripMenuItem
            // 
            this.всёToolStripMenuItem.Name = "всёToolStripMenuItem";
            this.всёToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.всёToolStripMenuItem.Text = "Всё";
            this.всёToolStripMenuItem.Click += new System.EventHandler(this.всёToolStripMenuItem_Click);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сохранитьКлючToolStripMenuItem,
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem,
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem,
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem,
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem,
            this.сохранитьВсёToolStripMenuItem});
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            // 
            // сохранитьКлючToolStripMenuItem
            // 
            this.сохранитьКлючToolStripMenuItem.Name = "сохранитьКлючToolStripMenuItem";
            this.сохранитьКлючToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьКлючToolStripMenuItem.Text = "Сохранить ключ";
            this.сохранитьКлючToolStripMenuItem.Click += new System.EventHandler(this.сохранитьКлючToolStripMenuItem_Click);
            // 
            // сохранитьЗашифрованноеСообщениеToolStripMenuItem
            // 
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem.Name = "сохранитьЗашифрованноеСообщениеToolStripMenuItem";
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem.Text = "Сохранить зашифрованное сообщение";
            this.сохранитьЗашифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.сохранитьЗашифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // сохранитьРасшифрованноеСообщениеToolStripMenuItem
            // 
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem.Name = "сохранитьРасшифрованноеСообщениеToolStripMenuItem";
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem.Text = "Сохранить расшифрованное сообщение";
            this.сохранитьРасшифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.сохранитьРасшифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem
            // 
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem.Name = "сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem";
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem.Text = "Сохранить ключ + зашифрованное сообщение";
            this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem
            // 
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem.Name = "сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem";
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem.Text = "Сохранить ключ + расшифрованное сообщение";
            this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem.Click += new System.EventHandler(this.сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem_Click);
            // 
            // сохранитьВсёToolStripMenuItem
            // 
            this.сохранитьВсёToolStripMenuItem.Name = "сохранитьВсёToolStripMenuItem";
            this.сохранитьВсёToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.сохранитьВсёToolStripMenuItem.Text = "Сохранить всё";
            this.сохранитьВсёToolStripMenuItem.Click += new System.EventHandler(this.сохранитьВсёToolStripMenuItem_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(752, 185);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "Удалить пробелы";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(13, 185);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "Удалить пробелы";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(248, 185);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(138, 23);
            this.button9.TabIndex = 15;
            this.button9.Text = "Только буквы";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(497, 185);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(141, 23);
            this.button10.TabIndex = 16;
            this.button10.Text = "Только буквы";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(752, 208);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(119, 23);
            this.button11.TabIndex = 17;
            this.button11.Text = "Удалить абзацы";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(12, 208);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(121, 23);
            this.button12.TabIndex = 18;
            this.button12.Text = "Удалить абзацы";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 345);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 19;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 326);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(913, 365);
            this.MinimumSize = new System.Drawing.Size(913, 365);
            this.Name = "Form5";
            this.Text = "Курсовая работа по теме \"Шифр Виженера\"";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ключToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зашифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem расшифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ключЗашифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ключРасшифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всёToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКлючToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьЗашифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьРасшифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКлючЗашифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКлючРасшифрованноеСообщениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьВсёToolStripMenuItem;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label4;
    }
}